"""
Allow levels to be imprted as a module
"""
