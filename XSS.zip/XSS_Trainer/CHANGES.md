# Version 0.3

  - Levels can now give out flags
  - Levels can now have Authors
  - Added some student contributed levels
  - We can now inject cookies into the render, so they can get Jacked

# Version 0.2

  - Rework So filters are in a seperate module to the app
  - Unit Tests and other fun stuff added
  
## Version 0.1

  - Initial Version.
  - Flask based frontend
  - Basic XSS detecton through selenium
  - PHP script execution
  
