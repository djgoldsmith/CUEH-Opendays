
## Plan

Standalone Documentation and Levels for XSS attacks

  - Make use of Flask to host the thing
  - Selenium (or Seleniniod) To check for XSS being Trigered
  
  - Training
    - Walk-through of Some simple XSS Style Attacks
	  - Triggering an Alert
	  - Page Redirection
	  - Session Jacking 
	  
  - Levels
    - N Levels to test skills
	- Some "Hand Holding"
	- Later Levels rely on research.
	- Explain Cutoff for Pass / First In Skills test.
	

## Levels

| Level | Lang   | Notes                              |
|-------|--------|------------------------------------|
| 0     | Python | Training                           |
| 1     | Python | Training                           |
| 2     | Python | CLient Side                        |
| 3     | Python | Basic Replace                      |
| 4     | Python | Regexp                             |
| 5     | PHP    | Preg_replace                       |
| 6     | Python | Stop Execute if "script" in string |
| 7     | Python | Markdown                           |
| 8     | HTML   | Attributes                         |


## Notes

This might be useful for text

https://pypi.org/project/jinja-markdown/

https://pythonhosted.org/Flask-Markdown/


https://github.com/andymccurdy/redis-py

