# XSS Trainer

Trainer for 245CT and XSS attacks

[![made-with-python](https://img.shields.io/badge/Made%20with-Python-1f425f.svg)](https://www.python.org/)
[![made-with-Markdown](https://img.shields.io/badge/Made%20with-Markdown-1f425f.svg)](http://commonmark.org)
[![Version-0.3](https://img.shields.io/badge/Version-0.3-green.svg)](https://shields.io/)


## Contributors

  - Dan (Dang42) 
  - Ben (Sharkmoos)



[![forthebadge](https://forthebadge.com/images/badges/powered-by-electricity.svg)](https://forthebadge.com)
